/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ssd1306.h"
#include "fonts.h"
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim6;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM6_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void delay (uint16_t time)
{
	__HAL_TIM_SET_COUNTER(&htim6, 0);
	while ((__HAL_TIM_GET_COUNTER(&htim6))<time);

}

//void Display_Temp (float Temp)
//{
//	char str[20] = {0};
	//ssd1306_SetCursor(0, 0);

//	sprintf (str, "TEMP:- %.2f ", Temp);
//	ssd1306_UpdateScreen(&hi2c1);
//}

uint8_t TxBuffer[128]; 
uint8_t RxBuffer[128]; 
int i;

uint8_t Temp_byte1, Temp_byte2;
uint8_t Temp_byte3, Temp_byte4;
uint16_t TEMP1;
uint16_t TEMP2;
float Temperature1 = 0;
float Temperature2 = 0;
float max1 = 0;
float max2 = 0;
float min1 = 50;
float min2 = 50;
uint8_t Presence1 = 0;
uint8_t Presence2 = 0;

void HandleError() 
{ 
 uint32_t uart_err; 
 uart_err=HAL_UART_GetError(&huart2);  
} 

void Set_Pin_Output (GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

void Set_Pin_Input (GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

#define DS18B20_1_PORT GPIOA
#define DS18B20_1_PIN GPIO_PIN_1

#define DS18B20_2_PORT GPIOA
#define DS18B20_2_PIN GPIO_PIN_0

uint8_t DS18B20_1_Start (void)
{
	uint8_t Response = 0;
	Set_Pin_Output(DS18B20_1_PORT, DS18B20_1_PIN);   // set the pin as output
	HAL_GPIO_WritePin (DS18B20_1_PORT, DS18B20_1_PIN, 0);  // pull the pin low
	delay (480);   // delay according to datasheet

	Set_Pin_Input(DS18B20_1_PORT, DS18B20_1_PIN);    // set the pin as input
	
	delay (80);    // delay according to datasheet
	if (!(HAL_GPIO_ReadPin (DS18B20_1_PORT, DS18B20_1_PIN))) Response = 1;    // if the pin is low i.e the presence pulse is detected
	else Response = -1;

	delay (400); // 480 us delay totally.

	return Response;
}

void DS18B20_1_Write (uint8_t data)
{
	Set_Pin_Output(DS18B20_1_PORT, DS18B20_1_PIN);  // set as output

	for (int i=0; i<8; i++)
	{
		if ((data & (1<<i))!=0)  // if the bit is high
		{
			// write 1
			Set_Pin_Output(DS18B20_1_PORT, DS18B20_1_PIN);  // set as output
			HAL_GPIO_WritePin (DS18B20_1_PORT, DS18B20_1_PIN, 0);  // pull the pin LOW
			delay (1);  // wait for 1 us

			Set_Pin_Input(DS18B20_1_PORT, DS18B20_1_PIN);  // set as input
			delay (50);  // wait for 60 us
		}

		else  // if the bit is low
		{
			// write 0
			Set_Pin_Output(DS18B20_1_PORT, DS18B20_1_PIN);
			HAL_GPIO_WritePin (DS18B20_1_PORT, DS18B20_1_PIN, 0);  // pull the pin LOW
			delay (50);  // wait for 60 us

			Set_Pin_Input(DS18B20_1_PORT, DS18B20_1_PIN);
		}
	}
}

uint8_t DS18B20_1_Read (void)
{
	uint8_t value=0;
	Set_Pin_Input(DS18B20_1_PORT, DS18B20_1_PIN);

	for (int i=0;i<8;i++)
	{
		Set_Pin_Output(DS18B20_1_PORT, DS18B20_1_PIN);   // set as output
		HAL_GPIO_WritePin (GPIOA, GPIO_PIN_1, 0);  // pull the data pin LOW
		delay (2);  // wait for 2 us
		Set_Pin_Input(DS18B20_1_PORT, DS18B20_1_PIN);  // set as input
		if (HAL_GPIO_ReadPin (GPIOA, GPIO_PIN_1))  // if the pin is HIGH
		{
			value |= 1<<i;  // read = 1
		}
		delay (60);  // wait for 60 us
	}
	return value;
}

uint8_t DS18B20_2_Start (void)
{
	uint8_t Response = 0;
	Set_Pin_Output(DS18B20_2_PORT, DS18B20_2_PIN);   // set the pin as output
	HAL_GPIO_WritePin (DS18B20_2_PORT, DS18B20_2_PIN, 0);  // pull the pin low
	delay (480);   // delay according to datasheet

	Set_Pin_Input(DS18B20_2_PORT, DS18B20_2_PIN);    // set the pin as input
	
	delay (80);    // delay according to datasheet
	if (!(HAL_GPIO_ReadPin (DS18B20_2_PORT, DS18B20_2_PIN))) Response = 1;    // if the pin is low i.e the presence pulse is detected
	else Response = -1;

	delay (400); // 480 us delay totally.

	return Response;
}

void DS18B20_2_Write (uint8_t data)
{
	Set_Pin_Output(DS18B20_2_PORT, DS18B20_2_PIN);  // set as output

	for (int i=0; i<8; i++)
	{
		if ((data & (1<<i))!=0)  // if the bit is high
		{
			// write 1
			Set_Pin_Output(DS18B20_2_PORT, DS18B20_2_PIN);  // set as output
			HAL_GPIO_WritePin (DS18B20_2_PORT, DS18B20_2_PIN, 0);  // pull the pin LOW
			delay (1);  // wait for 1 us

			Set_Pin_Input(DS18B20_2_PORT, DS18B20_2_PIN);  // set as input
			delay (50);  // wait for 50 us
		}

		else  // if the bit is low
		{
			// write 0
			Set_Pin_Output(DS18B20_2_PORT, DS18B20_2_PIN);
			HAL_GPIO_WritePin (DS18B20_2_PORT, DS18B20_2_PIN, 0);  // pull the pin LOW
			delay (50);  // wait for 50 us

			Set_Pin_Input(DS18B20_2_PORT, DS18B20_2_PIN);
		}
	}
}

uint8_t DS18B20_2_Read (void)
{
	uint8_t value=0;
	Set_Pin_Input(DS18B20_2_PORT, DS18B20_2_PIN);

	for (int i=0;i<8;i++)
	{
		Set_Pin_Output(DS18B20_2_PORT, DS18B20_2_PIN);   // set as output
		HAL_GPIO_WritePin (GPIOA, GPIO_PIN_0, 0);  // pull the data pin LOW
		delay (2);  // wait for 2 us
		Set_Pin_Input(DS18B20_2_PORT, DS18B20_2_PIN);  // set as input
		if (HAL_GPIO_ReadPin (GPIOA, GPIO_PIN_0))  // if the pin is HIGH
		{
			value |= 1<<i;  // read = 1
		}
		delay (60);  // wait for 60 us
	}
	return value;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
	
	sprintf((char *)TxBuffer,"Hello STM32 \n\r"); 
	if (HAL_UART_Transmit(&huart2,TxBuffer,strlen((const char *)TxBuffer),1000)!=HAL_OK)
		{  
			HandleError();    
		};
	
  MX_TIM6_Init();
	
	HAL_TIM_Base_Start(&htim6);
  /* USER CODE BEGIN 2 */
	SSD1306_Init(&hi2c1);
	//ssd1306_SetCursor(0,0);			
  //ssd1306_WriteString("PRASIDEDA", Font_11x18, White);
	//HAL_Delay(2000);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		
		Presence1 = DS18B20_1_Start ();
     DS18B20_1_Write (0xCC);  // skip ROM
     DS18B20_1_Write (0x44);  // convert t

     Presence1 = DS18B20_1_Start ();
     DS18B20_1_Write (0xCC);  // skip ROM
     DS18B20_1_Write (0xBE);  // Read Scratch-pad

     Temp_byte1 = DS18B20_1_Read();
     Temp_byte2 = DS18B20_1_Read();
     TEMP1 = ((Temp_byte2<<8))|Temp_byte1;
     Temperature1 = (float)TEMP1/16.0;  // resolution is 0.0625
		
		Presence2 = DS18B20_2_Start ();
     DS18B20_2_Write (0xCC);  // skip ROM
     DS18B20_2_Write (0x44);  // convert t

     Presence2 = DS18B20_2_Start ();
     DS18B20_2_Write (0xCC);  // skip ROM
     DS18B20_2_Write (0xBE);  // Read Scratch-pad

     Temp_byte3 = DS18B20_2_Read();
     Temp_byte4 = DS18B20_2_Read();
     TEMP2 = ((Temp_byte4<<8))|Temp_byte3;
     Temperature2 = (float)TEMP2/16.0;  // resolution is 0.0625
		
		if(Temperature1<min1)
		{
			min1 = Temperature1;
		}
		
		if(Temperature1>max1 && Temperature1<75)
		{
			max1 = Temperature1;
		}
		
		if(Temperature2<min2)
		{
			min2 = Temperature2;
		}
		
		if(Temperature2>max2 && Temperature2<75)
		{
			max2 = Temperature2;
		}

     HAL_Delay(2000);
			char str[20] = {0};
			ssd1306_SetCursor(0, 0);

			sprintf (str, "TEMP: %.2f ", Temperature1);
			ssd1306_WriteString(str, Font_11x18, White);
			ssd1306_UpdateScreen(&hi2c1);
			
					
		//	sprintf((char *)TxBuffer,"T1: %.2f;\t min1: %.2f;\t max1: %.2f\n T2: %.2f;\t min2: %.2f;\t max2: %.2f\r\n",
		//		Temperature1, min1, max1, Temperature2, min2, max2);
			sprintf((char *)TxBuffer, "%.2f,%.2f,%.2f,%.2f,%.2f,%.2f\r\n",
    Temperature1, min1, max1, Temperature2, min2, max2);
			
			if (HAL_UART_Transmit(&huart2, TxBuffer, strlen((const char *)TxBuffer), 4000) != HAL_OK)
				{
					HandleError();
				}
				
				/*	for (i=0;i<3;i++) 
			{ 
				sprintf((char *)TxBuffer,"%d, %d \n\r",i,i*i);    
				if (HAL_UART_Transmit(&huart2, TxBuffer, strlen((const char *)TxBuffer), 4000) != HAL_OK)
         {  
					 HandleError();    
         };  
      }  
			
			if (HAL_UART_Receive(&huart2,RxBuffer,10,1000)!=HAL_OK) 
				{ 
					HandleError(); 
				};
			*/
			
			
    // Display_Temp(Temperature);
		
	//	ssd1306_SetCursor(0,0);			
   // ssd1306_WriteString("Testukas", Font_11x18, White); 
	//	ssd1306_UpdateScreen(&hi2c1); 
		
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLLMUL_3;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLLDIV_2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00805C87;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 50-1;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 65535;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1|LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PA1 LD2_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_1|LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
